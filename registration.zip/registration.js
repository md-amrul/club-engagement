document.addEventListener("DOMContentLoaded", function () {
  const toggleSwitch = document.getElementById("theme-toggle");
  const togglePassword = document.getElementById("togglePassword");
  const passwordField = document.getElementById("password");

  // Dark Mode Toggle
  function setDarkMode(enabled) {
    if (enabled) {
      document.body.classList.add("dark-mode");
      localStorage.setItem("darkMode", "enabled");
    } else {
      document.body.classList.remove("dark-mode");
      localStorage.setItem("darkMode", "disabled");
    }
  }

  // Initialize dark mode based on localStorage setting
  if (localStorage.getItem("darkMode") === "enabled") {
    setDarkMode(true);
  }

  // Event listener for dark mode button
  toggleSwitch.addEventListener("click", function () {
    const darkModeEnabled = document.body.classList.contains("dark-mode");
    setDarkMode(!darkModeEnabled);
  });

  // Password Visibility Toggle
  togglePassword.addEventListener("click", function () {
    const type =
      passwordField.getAttribute("type") === "password" ? "text" : "password";
    passwordField.setAttribute("type", type);
    this.classList.toggle("fa-eye-slash"); // Toggle the eye icon
  });
});
