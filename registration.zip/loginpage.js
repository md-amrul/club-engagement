document.addEventListener("DOMContentLoaded", function () {
  // Function to set dark mode
  function setDarkMode(enabled) {
    if (enabled) {
      document.body.classList.add("dark-mode");
      localStorage.setItem("darkMode", "enabled");
    } else {
      document.body.classList.remove("dark-mode");
      localStorage.setItem("darkMode", "disabled");
    }
  }

  // Toggle dark mode on button click
  const toggleSwitch = document.querySelector("#theme-toggle");
  toggleSwitch.addEventListener("click", function () {
    const darkModeEnabled = document.body.classList.contains("dark-mode");
    setDarkMode(!darkModeEnabled);
  });

  // Check localStorage for dark mode setting and apply it
  if (localStorage.getItem("darkMode") === "enabled") {
    setDarkMode(true);
  }

  // Password Visibility Toggle
  const togglePassword = document.querySelector("#togglePassword");
  const password = document.querySelector("#password");

  // Toggle password visibility on eye icon click
  togglePassword.addEventListener("click", function (e) {
    const type =
      password.getAttribute("type") === "password" ? "text" : "password";
    password.setAttribute("type", type);

    // Toggle the eye icon (open/closed)
    this.classList.toggle("fa-eye-slash");
  });
});
